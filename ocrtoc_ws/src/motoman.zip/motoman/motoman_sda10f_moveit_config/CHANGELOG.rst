^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package motoman_sda10f_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.5 (2016-07-03)
------------------
* No changes

0.3.4 (2016-07-03)
------------------
* Support for multiple motion group control
* Contributors: Shaun Edwards, thiagodefreitas

0.3.3 (2014-02-07)
------------------

0.3.2 (2014-01-31)
------------------

0.3.1 (2014-01-30)
------------------
