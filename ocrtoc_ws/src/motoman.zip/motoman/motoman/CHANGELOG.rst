^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package motoman
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.5 (2016-07-03)
------------------
* No changes

0.3.4 (2016-07-03)
------------------
* Remove deprecated motoman_config pkg. Fix `#76 <https://github.com/shaun-edwards/motoman/issues/76>`_.
  Has been deprecated since 2014-01-28, see 1257a94b.
* Support for multiple motion group control
* Contributors: gavanderhoorn

0.3.3 (2014-02-07)
------------------
* No changes

0.3.2 (2014-01-31)
------------------
* Added build dependency on roslaunch to support packages

0.3.1 (2014-01-30)
------------------
* Synchronized versions for bloom release
* Updated motoman meta-package to include new packages
* Changed directory name from fs100 to motoman_driver
  Fix `#2 <https://github.com/shaun-edwards/motoman/issues/2>`_.
* rosbuild motoman stack has been converted to catkin metapackage
* Contributors: Shaun Edwards, gavanderhoorn, jrgnicho
