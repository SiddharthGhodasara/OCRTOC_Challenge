^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package motoman_sia10f_support
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.5 (2016-07-03)
------------------
* No changes

0.3.4 (2016-07-03)
------------------
* support: mark SIAx(d|f) pkgs as deprecated.
  And point users to the 'motoman_sia_support' package, which will be
  introduced in Jade.
* fixed motoman_sia10f macro name
* First version of the sia10f package
* Contributors: Dave Hershberger, Mathias Lüdtke, Shaun Edwards, gavanderhoorn, ros, thiagodefreitas

0.3.3 (2014-02-07)
------------------

0.3.2 (2014-01-31)
------------------

0.3.1 (2014-01-30)
------------------
